﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using System.Threading.Tasks;

namespace Рязанова_пп_Middleware
{
    public class MonkeyMiddleware
    {
        private readonly RequestDelegate _next;
        public MonkeyMiddleware(RequestDelegate next)
        {
            _next = next;
        }
        public async Task Invoke(HttpContext context)
        {
            var userAgent = context.Request.Headers["User-Agent"].ToString();
            if (userAgent.Contains("Edg"))
            {
                context.Response.StatusCode = 404;
                await context.Response.WriteAsync("404 Not Found");
            }
            else
            {
                context.Response.ContentType = "text/html";
                await context.Response.WriteAsync("~Обезьянка~");
            }
        }
    }
    public static class MonkeyMiddlewareExtensions
    {
        public static IApplicationBuilder UseMonkeyMiddleware(this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<MonkeyMiddleware>();
        }
    }
}
